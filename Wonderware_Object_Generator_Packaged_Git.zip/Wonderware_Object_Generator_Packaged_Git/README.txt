======================================================================================
Wonderware Object Generator Instructions
======================================================================================
1. Ensure when you unzipped you have a folder called json with a whole bunch of template files,
   a folder called packaged_exe with the application inside and a spreadsheet called WW_Object_Generator.
2. Open the spreadsheet WW_Object_Generator and add your tags you want to import to ArchestrA, ensure your areas already exist and that the templates your adding exist within the json folder. 
   If they don't then you will need to use the JSON_Template_Generator application.
3. Run the application and follow the GUI prompts and a import ready CSV will be outputted. To load this into ArchestrA just go Galaxy -> Galaxy Load then select the CSV.